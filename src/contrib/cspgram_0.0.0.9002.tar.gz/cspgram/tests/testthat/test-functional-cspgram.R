context('cspgram Functional Tests')


test_that('Test example 1', {
  expect_true(TRUE)
})

test_that('Test example 2', {
  expect_true(TRUE)
})
