#' @importFrom data.table data.table := %between%
#' @importFrom foreach foreach %do% %dopar%
NULL


globalVariables(c('p', 'period', 'chisq', 'df', 'pval', 'log_pval'))


#' Calculate chi-square periodogram
#'
#' Calculate the chi-square periodogram of a time-course.
#'
#' @param x Numeric vector of measurements.
#' @param deltat Numeric indicating the amount of time between measurements.
#' @param periodRange Numeric vector of the minimum and maximum values of the
#'   period, in units of `deltat`, for which to calculate the chi-squared
#'   statistic.
#' @param method Character indicating which method to use to calculate the chi-
#'   squared statistic. The standard method is not recommended.
#' @param na.action Function specifying how to handle `NA` values in `x`.
#'   Default is [imputeTS::na_ma()], which imputes missing values by
#'   weighted moving average.
#' @param dopar Logical indicating whether to run calculations in parallel, if
#'   a parallel backend has already been set up, e.g., using
#'   [doParallel::registerDoParallel()].
#'
#' @return `data.table` with columns `period`, `chisq`, `df`, `log_pval`, and
#'   `pval`. The log p-value is more reliable than the p-value itself, since R
#'   has finite precision, so p-values less than about 5e-324 will be set to 0.
#'
#' @example R/cspgram_example.R
#'
#' @export
cspgram = function(x, deltat, periodRange = c(18, 32),
                   method = c('greedy', 'conservative', 'standard'),
                   na.action = imputeTS::na_ma, dopar = TRUE) {

  method = match.arg(method)
  stopifnot(is.vector(x, 'numeric'),
            is.vector(deltat, 'numeric'),
            length(deltat) == 1L,
            deltat > 0,
            is.vector(periodRange, 'numeric'),
            length(periodRange) == 2L,
            all(periodRange >= 0),
            periodRange[2L] - periodRange[1L] > 0)

  pSpan = (periodRange[1L] / deltat):(periodRange[2L] / deltat)
  if (length(pSpan) == 0) {
    stop('deltat and periodRange are incompatible.')}

  if (isTRUE(dopar)) {
    doOp = `%dopar%`
  } else {
    doOp = `%do%`}

  x = na.action(x)
  k = length(x) %/% max(pSpan) # for conservative
  m = mean(x) # for greedy
  n = length(x)

  d = doOp(foreach(p = pSpan, .combine = rbind), {
    if (method == 'greedy') {
      k = n / p
      xNow = c(x, rep.int(NA, ceiling(k) * p - n))
      xMat = matrix(xNow, ncol = p, byrow = TRUE)
      xH = colMeans(xMat, na.rm = TRUE)
      qP = k * n * sum((xH - m)^2) / sum((x - m)^2)
    } else {
      if (method == 'standard') {
        k = n %/% p}
      xNow = x[1:(k * p)]
      mNow = mean(xNow)
      xMat = matrix(xNow, ncol = p, byrow = TRUE)
      xH = colMeans(xMat)
      qP = k * length(xNow) * sum((xH - mNow)^2) / sum((xNow - mNow)^2)}
    dNow = data.table(p = p, chisq = qP)})

  d[, period := p * deltat]
  d[, df := p - 1]
  d[, p := NULL]

  d[, log_pval := stats::pchisq(chisq, df, lower.tail = FALSE, log.p = TRUE)]
  d[, pval := exp(log_pval)]

  data.table::setcolorder(d, 'period')
  attr(d, 'method') = method
  return(d[])}
