library(testthat)
library(cspgram)

test_check("cspgram")
