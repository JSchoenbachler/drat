library(testthat)
library(spectr)

test_check("spectr")
