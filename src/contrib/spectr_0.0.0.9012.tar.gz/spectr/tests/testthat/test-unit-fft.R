context('FFT Unit Test')


test_that('FFT', {
  library(data.table)
  set.seed(1789)
  deltat = 0.1
  tau = 25
  tt = seq(0, 24 * 3, deltat)
  x = 3 * sin(tt / tau * 2 * pi) + rnorm(length(tt))
  fft = fftpgram(x, deltat,periodRange = c(20,30))
})
